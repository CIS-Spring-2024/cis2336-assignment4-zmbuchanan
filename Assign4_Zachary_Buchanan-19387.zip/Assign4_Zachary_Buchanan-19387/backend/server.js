const express = require('express');
const bodyParser = require('body-parser');

const app = express();
const port = 3000;

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

// Was having an incredibly difficult time getting POST requests working at the start, after getting them working I liked this logging functionality for the server-side terminal, so I kept it.
app.use((req, res, next) => {
console.log(`Received ${req.method} request to ${req.originalUrl}`);
console.log('Request body:', req.body);
next();
});

// POST request handler for the order form.
app.post('/order', (req, res) => {
    // Retrieve selected items and quantities from the request body.
    const { spaghettiQty, pizzaQty, saladQty, falafelQty } = req.body;

    // Validate quantities.
    if (spaghettiQty < 0 || pizzaQty < 0 || saladQty < 0 || falafelQty < 0) {
        return res.status(400).send('Error: Quantity cannot be negative.');
    }

    // Check if any quantity is over 10.
    if (spaghettiQty > 10 || pizzaQty > 10 || saladQty > 10 || falafelQty > 10) {
        return res.status(400).send('Error: We are not able to guarantee that large an order online, please come in to speak to the manager.');
    }

    // Calculate total cost.
    const totalCost = spaghettiQty * 8.99 + pizzaQty * 10.99 + saladQty * 7.99 + falafelQty * 9.99;

    // Create order summary message.
    let confirmationMessage = 'Order Successful!<br><br>Order Summary:<br>';
    if (spaghettiQty > 0) {
        confirmationMessage += `Spaghetti x ${spaghettiQty}<br>`;
    }
    if (pizzaQty > 0) {
        confirmationMessage += `Pepperoni Pizza x ${pizzaQty}<br>`;
    }
    if (saladQty > 0) {
        confirmationMessage += `Caesar Salad x ${saladQty}<br>`;
    }
    if (falafelQty > 0) {
        confirmationMessage += `Falafel Pita x ${falafelQty}<br>`;
    }
    confirmationMessage += `Total Cost: $${totalCost.toFixed(2)}`;

    // Send confirmation message as response.
    res.send(confirmationMessage);
});

// POST request handler for the contact form.
app.post('/submit_contact', (req, res) => {
    // Retrieve contact information from the request body.
    const { name, email, message } = req.body;

    // Send confirmation message.
    const confirmationMessage = `Thank you, ${name}, for reaching out to us! We will get back to you soon.`;
    res.send(confirmationMessage);
});



app.listen(port, () => {
    console.log(`Server is listening at http://localhost:3000`);
});
