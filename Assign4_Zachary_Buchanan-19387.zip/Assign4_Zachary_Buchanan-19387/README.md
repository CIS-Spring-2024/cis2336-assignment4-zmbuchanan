Welcome to the ReadMe for The Zackateria Website. If you have any questions, please do not hesitate to reach out on our Contact Us page, and I will reach back out as soon as possible.

Site Layout:
1. Main Page
2. Weekly Menu
3. Order Form
4. Biography
5. Contact Us

Frontend Dependencies:
1. CSS Stylesheet
2. Images

Backend Dependencies:
1. Node.js
2. Express.js
3. bodyParser

How to run server:
1. After installing Node.js, open your PowerShell terminal as administrator.
2. Input in the terminal (without quotes, and after changing the X's to the correct directory) "cd C:\XXXXX\Assign4_Zachary_Buchanan-19387\backend" and hit enter
3. Input in the terminal (without quotes) "node server.js" and hit enter.
4. Your terminal should now say: "Server is listening at http://localhost:3000" which means you should be available to receive POST requests from clients.
5. To test this, open the Order Form page and attempt to order 1 Spaghetti. You should be transferred to a new page, and your terminal should show the order request received.
